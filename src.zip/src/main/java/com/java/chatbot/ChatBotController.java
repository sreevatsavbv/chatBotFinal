package com.java.chatbot;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


import org.alicebot.ab.Bot;
import org.alicebot.ab.Chat;
import org.alicebot.ab.History;
import org.alicebot.ab.MagicBooleans;
import org.alicebot.ab.MagicStrings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.uuid.Generators;
import com.java.chatbot.model.ChatBotConvData;
import com.java.chatbot.model.ChatBotMasterData;
import com.java.chatbot.model.ChatRequest;
import com.java.chatbot.mybatis.ChatBotMapper;


@RestController
@RequestMapping("/chat")
public class ChatBotController {
	private  final boolean TRACE_MODE = false;
	static String botName = "super";
	

	@Autowired
	ChatBotMapper chatMapper;
@PostMapping(value="/chatResponse", produces= {"application/json"})
	public  String getBotResponse(@RequestBody ChatRequest chatRequest) {

		return getChatResponse(chatRequest);
	}

private  String getChatResponse(ChatRequest chatRequest) {
	try {
		
		String convId =chatRequest.getConversationId();
		String question = chatRequest.getQuestion();
		String intent= findIntentFromQuestion(question);
	//	chatService.getMasterAndDetailData(intent);
		List<ChatBotMasterData> dataList =chatMapper.getChatMasterData(intent);
		ChatBotConvData convData =chatMapper.findConversationStep(convId);
		if(convData == null) {
			convId = generateUUID();
		}
		
		String textLine = "";
		if(convData.getFlow_id()!= null) {
			textLine=convData.getFlow_id();
		}else {
			textLine ="101";
		}
		String resourcesPath = getResourcesPath();
		System.out.println(resourcesPath);
		MagicBooleans.trace_mode = TRACE_MODE;
		Bot bot = new Bot("super", resourcesPath);
		Chat chatSession = new Chat(bot);
		bot.brain.nodeStats();
		

		while (true) {
			System.out.print("Human : ");
			//textLine = chatRequest.getQuestion();
			if ((textLine == null) || (textLine.length() < 1))
				textLine = MagicStrings.null_input;
			if (textLine.equals("q")) {
				System.exit(0);
			} else if (textLine.equals("wq")) {
				bot.writeQuit();
				System.exit(0);
			} else {
				String request = textLine;
			//	if (MagicBooleans.trace_mode)
					System.out.println(
							"STATE=" + request + ":THAT=" + ((History) chatSession.thatHistory.get(0)).get(0)
									+ ":TOPIC=" + chatSession.predicates.get("topic"));
				String response = chatSession.multisentenceRespond(request);
				while (response.contains("&lt;"))
					response = response.replace("&lt;", "<");
				while (response.contains("&gt;"))
					response = response.replace("&gt;", ">");
				System.out.println("Robot : " + response);
				if(convData.getFlow_id()!= null) {
					chatMapper.updateConvData(convId, convData.getFlow_id());
				}
				chatMapper.insertConvData(convId, textLine);
				return response;
			}
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return null;
}

	private String findIntentFromQuestion(String question) {
		
		//RestFul service
		
	return "LOANS";
}

	private String generateUUID() {
		
		UUID uuid = Generators.randomBasedGenerator().generate();
		return uuid.toString();
}

	private static String getResourcesPath() {
		File currDir = new File(".");
		String path = currDir.getAbsolutePath();
		path = path.substring(0, path.length() - 2);
		System.out.println(path);
		String resourcesPath = path + File.separator + "src" + File.separator + "main" + File.separator + "resources";
		return resourcesPath;
	}
	
	private String redirectRequest(ChatRequest request) {
		switch(request.getIntent()) {
		case "interest":getInterestData();
				break;
				
		case "common": getDBSGreetData();
		
		}
		return null;
	}

	private void getDBSGreetData() {
		// TODO Auto-generated method stub
		
	}

	private void getInterestData() {
		// TODO Auto-generated method stub
		
	}
}
