package com.java.chatbot.mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.java.chatbot.model.ChatBotConvData;
import com.java.chatbot.model.ChatBotMasterData;

@Mapper
public interface ChatBotMapper {
	
	@Select("select * from guided_conversation_master WHERE intent_name=#{intent}")
    List<ChatBotMasterData> getChatMasterData(String intent);
	
	@Select("select * from guided_conversation_data WHERE conversation_id=#{convId} and status='RUNNING'") 
	ChatBotConvData findConversationStep(String convId);

	@Update("update guided_conversation_data set status='COMPLETED' where conversation_id=#{convId} and flow_id=#{flowId} ")
	void updateConvData(String convId, String flowId);

	@Insert("insert into guided_conversation_data values(#{},#{},#{},#{})")
	void insertConvData(String convId, String textLine);

}
