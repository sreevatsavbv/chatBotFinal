package com.java.chatbot.model;

public class ChatBotMasterData {

	private String intent_id;
	private String intent_name;
	private String flow_id;
	public String getIntent_id() {
		return intent_id;
	}
	public void setIntent_id(String intent_id) {
		this.intent_id = intent_id;
	}
	public String getIntent_name() {
		return intent_name;
	}
	public void setIntent_name(String intent_name) {
		this.intent_name = intent_name;
	}
	public String getFlow_id() {
		return flow_id;
	}
	public void setFlow_id(String flow_id) {
		this.flow_id = flow_id;
	}
	
	
}
