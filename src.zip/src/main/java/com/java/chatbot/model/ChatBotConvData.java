package com.java.chatbot.model;

public class ChatBotConvData {

	private String intent_id;
	private String flow_id;
	private String sub_flow_id;
	private String status;
	public String getIntent_id() {
		return intent_id;
	}
	public void setIntent_id(String intent_id) {
		this.intent_id = intent_id;
	}
	public String getFlow_id() {
		return flow_id;
	}
	public void setFlow_id(String flow_id) {
		this.flow_id = flow_id;
	}
	public String getSub_flow_id() {
		return sub_flow_id;
	}
	public void setSub_flow_id(String sub_flow_id) {
		this.sub_flow_id = sub_flow_id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
