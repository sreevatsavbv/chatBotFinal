package com.java.chatbot.model;

public class ChatBotDetailData {

}
